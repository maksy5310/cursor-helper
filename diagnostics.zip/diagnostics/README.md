# Cursor 工作空间诊断工具

## 📋 用途

这是一个独立的诊断脚本，可以在有问题的电脑上运行，快速扫描和收集 Cursor 工作空间的关键信息。适用于：

- 排查 Mac 和远程开发环境下的路径匹配问题
- 快速收集工作空间配置信息
- 生成诊断报告发送给开发者

## 🚀 使用方法

### 方式1: 直接运行（推荐）

```bash
# 进入诊断工具目录
cd cursor-helper/diagnostics

# 运行扫描脚本
node scan-workspaces.js
```

### 方式2: 在任意位置运行

```bash
# 直接指定脚本路径
node /path/to/cursor-helper/diagnostics/scan-workspaces.js
```

### Windows 用户

```powershell
# 进入目录
cd F:\spec-kit\cursor-helper\diagnostics

# 运行脚本
node scan-workspaces.js
```

### Mac/Linux 用户

```bash
# 进入目录
cd ~/projects/cursor-helper/diagnostics

# 运行脚本（也可以添加执行权限后直接运行）
chmod +x scan-workspaces.js
./scan-workspaces.js
```

## 📊 输出内容

脚本会输出以下信息：

### 1. 系统信息
- 操作系统类型和版本
- CPU 架构
- 用户主目录
- Cursor 用户数据目录

### 2. 工作空间列表
对每个工作空间输出：
- **工作空间 ID**：唯一标识符
- **类型**：单根工作空间 / 多根工作空间
- **原始路径**：存储在 workspace.json 中的原始路径
- **解析后路径**：经过 URL 解码后的实际路径
- **数据库状态**：是否存在、文件大小
- **远程标识**：是否为远程开发工作空间

### 3. 统计信息
- 总工作空间目录数
- 有效工作空间数
- 有数据库的工作空间数
- 远程工作空间数

### 4. 全局数据库
- 全局数据库路径和状态

### 5. 诊断建议
根据扫描结果给出针对性建议

## 📄 诊断报告

脚本运行后会在当前目录生成 `workspace-diagnostic-report.json` 文件，包含完整的诊断信息。

**报告结构：**

```json
{
  "platform": "darwin",
  "osType": "Darwin",
  "osRelease": "21.6.0",
  "arch": "x64",
  "homeDir": "/Users/username",
  "cursorUserDataDir": "/Users/username/Library/Application Support/Cursor/User",
  "workspaceStorageDir": "/Users/username/Library/Application Support/Cursor/User/workspaceStorage",
  "totalWorkspaces": 5,
  "validWorkspaces": 5,
  "globalDatabase": {
    "path": "/Users/username/Library/Application Support/Cursor/User/globalStorage/state.vscdb",
    "exists": true,
    "size": 1048576
  },
  "workspaces": [
    {
      "id": "1a2b3c4d5e6f7g8h",
      "type": "folder",
      "isRemote": false,
      "originalPath": "file:///Users/username/project",
      "decodedPath": "/Users/username/project",
      "database": {
        "exists": true,
        "path": "/Users/username/Library/Application Support/Cursor/User/workspaceStorage/1a2b3c4d5e6f7g8h/state.vscdb",
        "size": 524288,
        "hasWal": true,
        "hasShm": true
      },
      "workspaceJson": {
        "folder": "file:///Users/username/project"
      }
    }
  ],
  "scanTime": "2026-01-21T12:34:56.789Z"
}
```

## 🎯 典型使用场景

### 场景1: Mac 下看不到会话列表

1. 运行诊断脚本
2. 查看输出，确认是否找到工作空间
3. 查看工作空间的路径格式是否正确
4. 将诊断报告发送给开发者

### 场景2: 远程开发无法识别工作空间

1. 运行诊断脚本
2. 查看"远程工作空间"部分
3. 对比原始路径和解析后路径
4. 检查本地路径是否与远程路径的项目名称一致

### 场景3: 提交 Bug 报告

1. 运行诊断脚本
2. 生成 `workspace-diagnostic-report.json`
3. 在 GitHub Issues 中附上这个报告
4. 描述遇到的问题

## 📝 输出示例

### Windows 系统

```
================================================================================
Cursor 工作空间诊断扫描工具
================================================================================

1. 系统信息:
   操作系统: win32 (Windows_NT 10.0.22000)
   架构: x64
   用户主目录: C:\Users\Username
   Cursor 用户数据目录: C:\Users\Username\AppData\Roaming\Cursor\User
   工作空间存储目录: C:\Users\Username\AppData\Roaming\Cursor\User\workspaceStorage

2. 扫描工作空间:

   工作空间 abc123def456:
   ├─ 类型: 单根工作空间
   ├─ 原始路径: file:///f%3A/spec-kit/cursor-helper
   ├─ 解析后路径: f:\spec-kit\cursor-helper
   ├─ 数据库文件: ✓ 存在
   │  └─ 大小: 512 KB
   │  └─ WAL 文件: ✓
   │  └─ SHM 文件: ✓

3. 统计信息:
   总工作空间目录数: 3
   有效工作空间数: 3
   有数据库的工作空间: 2
   远程工作空间: 0

4. 全局数据库:
   路径: C:\Users\Username\AppData\Roaming\Cursor\User\globalStorage\state.vscdb
   状态: ✓ 存在
   大小: 1.5 MB

================================================================================
✓ 诊断完成
================================================================================

诊断报告已保存到: workspace-diagnostic-report.json
```

### Mac 系统

```
================================================================================
Cursor 工作空间诊断扫描工具
================================================================================

1. 系统信息:
   操作系统: darwin (Darwin 21.6.0)
   架构: arm64
   用户主目录: /Users/username
   Cursor 用户数据目录: /Users/username/Library/Application Support/Cursor/User
   工作空间存储目录: /Users/username/Library/Application Support/Cursor/User/workspaceStorage

2. 扫描工作空间:

   工作空间 xyz789abc123:
   ├─ 类型: 单根工作空间
   ├─ 原始路径: file:///Users/username/project
   ├─ 解析后路径: /Users/username/project
   ├─ 数据库文件: ✓ 存在
   │  └─ 大小: 256 KB
   │  └─ WAL 文件: ✓
   │  └─ SHM 文件: ✓

3. 统计信息:
   总工作空间目录数: 2
   有效工作空间数: 2
   有数据库的工作空间: 2
   远程工作空间: 0

5. 诊断建议:
   ✓ 找到了有效的工作空间和数据库
```

### 远程开发

```
   工作空间 remote123xyz:
   ├─ 类型: 单根工作空间 (远程)
   ├─ 原始路径: vscode-remote://ssh-remote+myserver/home/user/project
   ├─ 解析后路径: /home/user/project
   ├─ 数据库文件: ✓ 存在
   │  └─ 大小: 384 KB
   │  └─ WAL 文件: ✓
   │  └─ SHM 文件: ✓

5. 诊断建议:
   ✓ 找到了有效的工作空间和数据库

   远程工作空间说明：
   - ID: remote123xyz
     原始: vscode-remote://ssh-remote+myserver/home/user/project
     解析: /home/user/project
   提示：远程工作空间需要使用路径后缀匹配
```

## ⚠️ 注意事项

1. **Node.js 要求**：需要安装 Node.js (建议 v18+)
2. **权限问题**：确保有权限读取 Cursor 用户数据目录
3. **隐私保护**：诊断报告包含完整路径，分享前请检查是否有敏感信息

## 🔧 故障排查

### 错误: 工作空间存储目录不存在

**原因**：Cursor 尚未运行过，或者安装路径不对

**解决**：
1. 确认已安装 Cursor
2. 至少运行一次 Cursor
3. 在 Cursor 中打开一个项目

### 错误: 未找到任何有效的工作空间

**原因**：Cursor 运行过但没有创建工作空间数据

**解决**：
1. 在 Cursor 中打开项目
2. 使用 Composer 进行对话
3. 等待几分钟后重新运行脚本

### 错误: Cannot find module

**原因**：Node.js 未安装或版本太低

**解决**：
```bash
# 检查 Node.js 版本
node --version

# 如果未安装，请访问 https://nodejs.org/ 下载安装
```

## 📮 提交诊断报告

如果遇到问题需要开发者帮助：

1. 运行诊断脚本
2. 复制控制台输出
3. 附上生成的 `workspace-diagnostic-report.json` 文件
4. 在 [GitHub Issues](https://github.com/howelljiang/cursor-helper/issues) 提交

**提交模板：**

```markdown
## 问题描述
[描述你遇到的问题]

## 系统信息
- 操作系统: [Mac/Windows/Linux]
- 是否远程开发: [是/否]

## 诊断结果
[粘贴控制台输出]

## 诊断报告
[附上 workspace-diagnostic-report.json 文件]
```

## 🤝 贡献

如果你发现脚本有问题或想要改进，欢迎提交 PR！

## 📄 许可证

ISC License - 与主项目保持一致
